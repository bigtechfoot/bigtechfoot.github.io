import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class MAZE_GENERATOR extends PApplet {

// Maze Generator

class cell {
  boolean top = true;
  boolean rig = true;
  boolean bot = true;
  boolean lef = true;
  boolean searched = false;
  boolean current = false;
  int x = 0;
  int y = 0;
  
  cell(int xx, int yy) {
    x = xx;
    y = yy;
  }
  
  public void show() {
    noStroke();
    if(searched){fill(color(100, 100, 255));}
    if(!searched){fill(color(100, 100, 100));}
    if(current){fill(color(0, 255, 0));}
    rect(x, y, x+r, y+r);
    stroke(1);
    if(top){line(x, y, x+r, y);}
    if(rig){line(x+r-1, y-1, x+r-1, y+r-1);}
    if(bot){line(x+r-1, y+r-1, x-1, y+r-1);}
    if(lef){line(x, y+r, x, y);}    
  }
}

class runner {
  int x;
  int y;
  int xpast[];
  int ypast[];
  int current;
  
  runner() {
    x = 0;
    y = 0;
    l = h*w;
    xpast = new int[l];
    ypast = new int[l];
    current = 0;
  }
  
  public int neighbor() {
    int rand = floor(random(4));
    int dir = floor(random(2));
    dir *= 2;
    dir--;
    int count = 0;
    while (count < 4) {
      rand = (rand+4)%4;
      switch (rand) {
        case 0:
          if (y < 1 || grid[x][y-1].searched) {
            count++;
            rand+=dir;
            break;
          } else {
            return rand;
          }
        case 1:
          if (x >= w-1 || grid[x+1][y].searched) {
            count++;
            rand+=dir;
            break;
          }
          return rand;
        case 2:
          if (y >= h-1 || grid[x][y+1].searched) {
            count++;
            rand+=dir;
            break;
          }
          return rand;
        case 3:
          if (x < 1 || grid[x-1][y].searched) {
            count++;
            rand+=dir;
            break;
          }
          return rand;
        default:
          print("NOPE");
      }
    }
    return 4;
  }
  
  public boolean run() {
    int n = neighbor();
    switch (n) {
      case 0:
        grid[x][y].searched = true;
        grid[x][y].top = false;
        grid[x][y].current = false;
        xpast[current] = x;
        ypast[current] = y;
        current++;
        y--;
        grid[x][y].bot = false;
        grid[x][y].current = true;
        break;
      case 1:
        grid[x][y].searched = true;
        grid[x][y].rig = false;
        grid[x][y].current = false;
        xpast[current] = x;
        ypast[current] = y;
        current++;
        x++;
        grid[x][y].lef = false;
        grid[x][y].current = true;
        break;
      case 2:
        grid[x][y].searched = true;
        grid[x][y].bot = false;
        grid[x][y].current = false;
        xpast[current] = x;
        ypast[current] = y;
        current++;
        y++;
        grid[x][y].top = false;
        grid[x][y].current = true;
        break;
      case 3:
        grid[x][y].searched = true;
        grid[x][y].lef = false;
        grid[x][y].current = false;
        xpast[current] = x;
        ypast[current] = y;
        current++;
        x--;
        grid[x][y].rig = false;
        grid[x][y].current = true;
        break;
      case 4:
        grid[x][y].searched = true;
        grid[x][y].current = false;
        current--;
        x = xpast[current];
        y = ypast[current];
        grid[x][y].current = true;
        if (x == 0 && y == 0) {
          grid[x][y].current = false;
          return false;
        } else {
          return true;
        }
    }
    return true;
  }
}

cell grid[][];
int w;
int h;
int r;
int l;
boolean done = false;
runner go;


public void setup() {
  //fullScreen();
  
  r = 20;
  w = width/r;
  h = height/r;
  l = w*h;
  go = new runner();
  grid = new cell[w][h];
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      grid[i][j] = new cell(i*r, j*r);
    }
  }
}

public void draw() {
  delay(0);
  if(!done) {
    done = !go.run();
    for (int i = 0; i < w; i++) {
      for (int j = 0; j < h; j++) {
        grid[i][j].show();
      }
    }
  } else {
    noLoop();
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "MAZE_GENERATOR" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
