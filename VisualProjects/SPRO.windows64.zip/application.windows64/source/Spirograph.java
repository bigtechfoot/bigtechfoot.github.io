import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Spirograph extends PApplet {



ControlP5 cp5;
Arm arm1, arm2, arm3;
int arm_speed1 = 1;
int arm_speed2 = 2;
int arm_speed3 = 3;
int count = 0;
int state = 1;
boolean finished = false;
float[] x = new float[10000];
float[] y = new float[10000];

class Arm {
  float x;
  float y;
  float r;
  
  Arm(float xx, float yy, float rr) {
    x = xx;
    y = yy;
    r = rr;
  }
  
  public float xend() {
    return x+(75*cos(r));
  }
  public float yend() {
    return y+(75*sin(r));
  }
  
  public void Draw() {
    strokeWeight(5);
    line(x, y, xend(), yend());
  }
  
  public void Draw(Arm a) {
    x = a.xend();
    y = a.yend();
    strokeWeight(5);
    line(x, y, xend(), yend());
  }
  
} //class Arm

public void setup() {
  
  cp5 = new ControlP5(this);
  cp5.addSlider("arm_speed1")
     .setPosition(50, 50)
     .setRange(0,30);
  cp5.addSlider("arm_speed2")
     .setPosition(250, 50)
     .setRange(0,30);
  cp5.addSlider("arm_speed3")
     .setPosition(450, 50)
     .setRange(0,30);
  arm1 = new Arm(300, 300, -PI/4);
  arm2 = new Arm(arm1.xend(), arm1.yend(), -PI/4);
  arm3 = new Arm(arm2.xend(), arm2.yend(), -PI/4);
} // void setup

public void keyPressed() {
  state = (state+1) % 2;
  switch (state) {
    case 0:
      finished = true;
      break;
    case 1:
      x = new float[10000];
      y = new float[10000];
      count = 0; 
      finished = false;
      break;
  }
}

public void draw() {
  background(200);
  fill(0);
  text("Press any Key to Pause/Clear the Sketch", (width/2)-120, height-40);
  if (!finished) {
    arm1.r+=radians(arm_speed1);
    arm1.Draw();
    arm2.r+=radians(arm_speed2);
    arm2.Draw(arm1);
    arm3.r+=radians(arm_speed3);
    arm3.Draw(arm2);
    if (count != 10000) {
      //x = push(x, arm3.xend());
      x[count] = arm3.xend();
      y[count] = arm3.yend();
      count++;
      if (floor(x[count-1]) == floor(x[0]) && floor(y[count-1]) == floor(y[0]) && count > 1) {
        finished = true;
        keyPressed();
      }
    }
  }
  for (int i = 1; i < count; i++) {
    line(x[i-1], y[i-1], x[i], y[i]);
  }
} // void draw

/*
void slider(float theColor) {
  myColor = color(theColor);
  println("a slider event. setting background to "+theColor);
}
*/
  public void settings() {  size(600, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Spirograph" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
