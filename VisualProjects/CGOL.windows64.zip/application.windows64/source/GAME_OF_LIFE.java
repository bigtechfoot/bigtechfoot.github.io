import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class GAME_OF_LIFE extends PApplet {

// Conway's Game of Life

int grid[][];
int newg[][];
int w;
int h;
int r;

public void setup() {
  
  r = 10;
  w = width/r;
  h = height/r;
  grid = new int[w][h];
  newg = new int[w][h];
  
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      grid[i][j] = floor(random(2));
      newg[i][j] = 0;
    }
  }
}

public int neighbors(int x, int y) {
  int count = 0;
  
  for (int i = -1; i <= 1; i++) {
    for (int j = -1; j <= 1; j++) {
      count += grid[(x+i+w)%w][(y+j+h)%h];
    }
  }
  count -= grid[x][y];
  
  return count;
}

public void check_state() {
  for (int j = 0; j < h; j++) {
    for (int i = 0; i < w; i++) {
      int n = neighbors(i, j);
      if (grid[i][j] == 0 && n == 3) {
        newg[i][j] = 1;
      } else if (grid[i][j] == 1 && (n < 2 || n > 3)) {
        newg[i][j] = 0;
      } else {
        newg[i][j] = grid[i][j];
      }
    }
  }
}

public void draw() {
  noStroke();
  
  check_state();
  
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      grid[i][j] = newg[i][j];
    }
  }
  
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      if (grid[i][j] == 0) {
        fill(100);
      } else {
        fill(255);
      }
      rect(i*10, j*10, (i*10)+10, (j*10)+10);
    }
  }
  delay(0);
  
}
  public void settings() {  size(1000,500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "GAME_OF_LIFE" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
